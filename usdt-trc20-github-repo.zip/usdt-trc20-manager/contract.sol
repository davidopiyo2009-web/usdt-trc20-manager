// SPDX-License-Identifier: MIT
pragma solidity ^0.8.25;

/**
 * @title TRC20USDT
 * @dev Enhanced TRC20 USDT Token Implementation
 * @author Enhanced by AI Assistant
 * @notice This contract implements a TRC20-compatible USDT token with additional security features
 * @dev Features:
 * - Pausable functionality for emergency stops
 * - Blacklist functionality for compliance
 * - Gas-optimized operations
 * - Built-in overflow protection (Solidity 0.8+)
 * - Enhanced events for better transparency
 */


interface ITRC20 {
  /**
   * @dev Returns the amount of tokens in existence.
   */
  function totalSupply() external view returns (uint256);

  /**
   * @dev Returns the token decimals.
   */
  function decimals() external view returns (uint8);

  /**
   * @dev Returns the token symbol.
   */
  function symbol() external view returns (string memory);

  /**
  * @dev Returns the token name.
  */
  function name() external view returns (string memory);

  /**
   * @dev Returns the bep token owner.
   */
  function getOwner() external view returns (address);

  /**
   * @dev Returns the amount of tokens owned by `account`.
   */
  function balanceOf(address account) external view returns (uint256);

  /**
   * @dev Moves `amount` tokens from the caller's account to `recipient`.
   *
   * Returns a boolean value indicating whether the operation succeeded.
   *
   * Emits a {Transfer} event.
   */
  function transfer(address recipient, uint256 amount) external returns (bool);

  /**
   * @dev Returns the remaining number of tokens that `spender` will be
   * allowed to spend on behalf of `owner` through {transferFrom}. This is
   * zero by default.
   *
   * This value changes when {approve} or {transferFrom} are called.
   */
  function allowance(address _owner, address spender) external view returns (uint256);

  /**
   * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
   *
   * Returns a boolean value indicating whether the operation succeeded.
   *
   * IMPORTANT: Beware that changing an allowance with this method brings the risk
   * that someone may use both the old and the new allowance by unfortunate
   * transaction ordering. One possible solution to mitigate this race
   * condition is to first reduce the spender's allowance to 0 and set the
   * desired value afterwards:
   * https://github.com/ethereum/EIPs/issues/20#issuecomment-263524729
   *
   * Emits an {Approval} event.
   */
  function approve(address spender, uint256 amount) external returns (bool);

  /**
   * @dev Moves `amount` tokens from `sender` to `recipient` using the
   * allowance mechanism. `amount` is then deducted from the caller's
   * allowance.
   *
   * Returns a boolean value indicating whether the operation succeeded.
   *
   * Emits a {Transfer} event.
   */
  function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);

  /**
   * @dev Emitted when `value` tokens are moved from one account (`from`) to
   * another (`to`).
   *
   * Note that `value` may be zero.
   */
  event Transfer(address indexed from, address indexed to, uint256 value);

  /**
   * @dev Emitted when the allowance of a `spender` for an `owner` is set by
   * a call to {approve}. `value` is the new allowance.
   */
  event Approval(address indexed owner, address indexed spender, uint256 value);
}

/*
 * @dev Provides information about the current execution context, including the
 * sender of the transaction and its data. While these are generally available
 * via msg.sender and msg.data, they should not be accessed in such a direct
 * manner, since when dealing with GSN meta-transactions the account sending and
 * paying for execution may not be the actual sender (as far as an application
 * is concerned).
 *
 * This contract is only required for intermediate, library-like contracts.
 */
contract Context {
  // Empty constructor, to prevent people from mistakenly deploying
  // an instance of this contract, which should be used via inheritance.
  constructor() { }

  function _msgSender() internal view returns (address) {
    return msg.sender;
  }

  function _msgData() internal view returns (bytes memory) {
    this; // silence state mutability warning without generating bytecode - see https://github.com/ethereum/solidity/issues/2691
    return msg.data;
  }
}

/**
 * @dev Contract module which allows children to implement an emergency stop
 * mechanism that can be triggered by an authorized account.
 *
 * This module is used through inheritance. It will make available the
 * modifiers `whenNotPaused` and `whenPaused`, which can be applied to
 * the functions of your contract. Note that they will not be pausable by
 * simply including this module, only once the modifiers are put in place.
 */
contract Pausable is Context {
    /**
     * @dev Emitted when the pause is triggered by `account`.
     */
    event Paused(address account);

    /**
     * @dev Emitted when the pause is lifted by `account`.
     */
    event Unpaused(address account);

    bool private _paused;

    /**
     * @dev Initializes the contract in unpaused state.
     */
    constructor() {
        _paused = false;
    }

    /**
     * @dev Returns true if the contract is paused, and false otherwise.
     */
    function paused() public view returns (bool) {
        return _paused;
    }

    /**
     * @dev Modifier to make a function callable only when the contract is not paused.
     *
     * Requirements:
     *
     * - The contract must not be paused.
     */
    modifier whenNotPaused() {
        require(!_paused, "Pausable: paused");
        _;
    }

    /**
     * @dev Modifier to make a function callable only when the contract is paused.
     *
     * Requirements:
     *
     * - The contract must be paused.
     */
    modifier whenPaused() {
        require(_paused, "Pausable: not paused");
        _;
    }

    /**
     * @dev Triggers stopped state.
     *
     * Requirements:
     *
     * - The contract must not be paused.
     */
    function _pause() internal virtual whenNotPaused {
        _paused = true;
        emit Paused(_msgSender());
    }

    /**
     * @dev Returns to normal state.
     *
     * Requirements:
     *
     * - The contract must be paused.
     */
    function _unpause() internal virtual whenPaused {
        _paused = false;
        emit Unpaused(_msgSender());
    }
}

/**
 * @dev Contract module which provides a basic access control mechanism, where
 * there is an account (an owner) that can be granted exclusive access to
 * specific functions.
 *
 * By default, the owner account will be the one that deploys the contract. This
 * can later be changed with {transferOwnership}.
 *
 * This module is used through inheritance. It will make available the modifier
 * `onlyOwner`, which can be applied to your functions to restrict their use to
 * the owner.
 */
contract Ownable is Context {
  address private _owner;

  event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

  /**
   * @dev Initializes the contract setting the deployer as the initial owner.
   */
  constructor() {
    address msgSender = _msgSender();
    _owner = msgSender;
    emit OwnershipTransferred(address(0), msgSender);
  }

  /**
   * @dev Returns the address of the current owner.
   */
  function owner() public view returns (address) {
    return _owner;
  }

  /**
   * @dev Throws if called by any account other than the owner.
   */
  modifier onlyOwner() {
    require(_owner == _msgSender(), "Ownable: caller is not the owner");
    _;
  }

  /**
   * @dev Leaves the contract without owner. It will not be possible to call
   * `onlyOwner` functions anymore. Can only be called by the current owner.
   *
   * NOTE: Renouncing ownership will leave the contract without an owner,
   * thereby removing any functionality that is only available to the owner.
   */
  function renounceOwnership() public onlyOwner {
    emit OwnershipTransferred(_owner, address(0));
    _owner = address(0);
  }

  /**
   * @dev Transfers ownership of the contract to a new account (`newOwner`).
   * Can only be called by the current owner.
   */
  function transferOwnership(address newOwner) public onlyOwner {
    _transferOwnership(newOwner);
  }

  /**
   * @dev Transfers ownership of the contract to a new account (`newOwner`).
   */
  function _transferOwnership(address newOwner) internal {
    require(newOwner != address(0), "Ownable: new owner is the zero address");
    emit OwnershipTransferred(_owner, newOwner);
    _owner = newOwner;
  }
}

contract TRC20USDT is Context, ITRC20, Ownable, Pausable {
  mapping (address => uint256) private _balances;
  mapping (address => mapping (address => uint256)) private _allowances;
  mapping (address => bool) private _blacklisted;

  uint256 private _totalSupply;
  uint8 private _decimals;
  string private _symbol;
  string private _name;

  // Events
  event Blacklisted(address indexed account);
  event Unblacklisted(address indexed account);
  event Mint(address indexed to, uint256 amount);
  event Burn(address indexed from, uint256 amount);

  constructor() {
    _name = "Tether USD";
    _symbol = "USDT";
    _decimals = 18;
    _totalSupply = 30000000000000000000000000;
    _balances[msg.sender] = _totalSupply;

    emit Transfer(address(0), msg.sender, _totalSupply);
  }

  /**
   * @dev Returns the bep token owner.
   */
  function getOwner() external override view returns (address) {
    return owner();
  }

  /**
   * @dev Returns the token decimals.
   */
  function decimals() external override view returns (uint8) {
    return _decimals;
  }

  /**
   * @dev Returns the token symbol.
   */
  function symbol() external override view returns (string memory) {
    return _symbol;
  }

  /**
  * @dev Returns the token name.
  */
  function name() external override view returns (string memory) {
    return _name;
  }

  /**
   * @dev See {TRC20-totalSupply}.
   */
  function totalSupply() external override view  returns (uint256) {
    return _totalSupply;
  }

  /**
   * @dev See {TRC20-balanceOf}.
   */
  function balanceOf(address account) external override view returns (uint256) {
    return _balances[account];
  }

  /**
   * @dev See {TRC20-transfer}.
   *
   * Requirements:
   *
   * - `recipient` cannot be the zero address.
   * - the caller must have a balance of at least `amount`.
   * - contract must not be paused.
   * - addresses must not be blacklisted.
   */
  function transfer(address recipient, uint256 amount) external override whenNotPaused returns (bool) {
    require(!_blacklisted[_msgSender()], "TRC20: sender is blacklisted");
    require(!_blacklisted[recipient], "TRC20: recipient is blacklisted");
    _transfer(_msgSender(), recipient, amount);
    return true;
  }

  /**
   * @dev See {TRC20-allowance}.
   */
  function allowance(address owner, address spender) external override view returns (uint256) {
    return _allowances[owner][spender];
  }

  /**
   * @dev See {TRC20-approve}.
   *
   * Requirements:
   *
   * - `spender` cannot be the zero address.
   * - contract must not be paused.
   * - addresses must not be blacklisted.
   */
  function approve(address spender, uint256 amount) external override whenNotPaused returns (bool) {
    require(!_blacklisted[_msgSender()], "TRC20: sender is blacklisted");
    require(!_blacklisted[spender], "TRC20: spender is blacklisted");
    _approve(_msgSender(), spender, amount);
    return true;
  }

  /**
   * @dev See {TRC20-transferFrom}.
   *
   * Emits an {Approval} event indicating the updated allowance. This is not
   * required by the EIP. See the note at the beginning of {TRC20};
   *
   * Requirements:
   * - `sender` and `recipient` cannot be the zero address.
   * - `sender` must have a balance of at least `amount`.
   * - the caller must have allowance for `sender`'s tokens of at least
   * `amount`.
   * - contract must not be paused.
   * - addresses must not be blacklisted.
   */
  function transferFrom(address sender, address recipient, uint256 amount) external override whenNotPaused returns (bool) {
    require(!_blacklisted[sender], "TRC20: sender is blacklisted");
    require(!_blacklisted[recipient], "TRC20: recipient is blacklisted");
    require(!_blacklisted[_msgSender()], "TRC20: caller is blacklisted");
    
    _transfer(sender, recipient, amount);
    _approve(sender, _msgSender(), _allowances[sender][_msgSender()] - amount);
    return true;
  }

  /**
   * @dev Atomically increases the allowance granted to `spender` by the caller.
   *
   * This is an alternative to {approve} that can be used as a mitigation for
   * problems described in {TRC20-approve}.
   *
   * Emits an {Approval} event indicating the updated allowance.
   *
   * Requirements:
   *
   * - `spender` cannot be the zero address.
   * - contract must not be paused.
   * - addresses must not be blacklisted.
   */
  function increaseAllowance(address spender, uint256 addedValue) public whenNotPaused returns (bool) {
    require(!_blacklisted[_msgSender()], "TRC20: sender is blacklisted");
    require(!_blacklisted[spender], "TRC20: spender is blacklisted");
    _approve(_msgSender(), spender, _allowances[_msgSender()][spender] + addedValue);
    return true;
  }

  /**
   * @dev Atomically decreases the allowance granted to `spender` by the caller.
   *
   * This is an alternative to {approve} that can be used as a mitigation for
   * problems described in {TRC20-approve}.
   *
   * Emits an {Approval} event indicating the updated allowance.
   *
   * Requirements:
   *
   * - `spender` cannot be the zero address.
   * - `spender` must have allowance for the caller of at least
   * `subtractedValue`.
   * - contract must not be paused.
   * - addresses must not be blacklisted.
   */
  function decreaseAllowance(address spender, uint256 subtractedValue) public whenNotPaused returns (bool) {
    require(!_blacklisted[_msgSender()], "TRC20: sender is blacklisted");
    require(!_blacklisted[spender], "TRC20: spender is blacklisted");
    require(_allowances[_msgSender()][spender] >= subtractedValue, "TRC20: decreased allowance below zero");
    _approve(_msgSender(), spender, _allowances[_msgSender()][spender] - subtractedValue);
    return true;
  }

  /**
   * @dev Blacklist an address to prevent transfers.
   * Can only be called by the owner.
   */
  function blacklist(address account) external onlyOwner {
    require(account != address(0), "TRC20: blacklist the zero address");
    _blacklisted[account] = true;
    emit Blacklisted(account);
  }

  /**
   * @dev Remove an address from blacklist.
   * Can only be called by the owner.
   */
  function unblacklist(address account) external onlyOwner {
    require(account != address(0), "TRC20: unblacklist the zero address");
    _blacklisted[account] = false;
    emit Unblacklisted(account);
  }

  /**
   * @dev Check if an address is blacklisted.
   */
  function isBlacklisted(address account) external view returns (bool) {
    return _blacklisted[account];
  }

  /**
   * @dev Pause the contract to prevent transfers.
   * Can only be called by the owner.
   */
  function pause() external onlyOwner {
    _pause();
  }

  /**
   * @dev Unpause the contract to allow transfers.
   * Can only be called by the owner.
   */
  function unpause() external onlyOwner {
    _unpause();
  }

  /**
   * @dev Creates `amount` tokens and assigns them to `to`, increasing
   * the total supply.
   *
   * Requirements
   *
   * - `msg.sender` must be the token owner
   * - `to` cannot be the zero address
   * - `to` must not be blacklisted
   */
  function mint(address to, uint256 amount) public onlyOwner returns (bool) {
    require(to != address(0), "TRC20: mint to the zero address");
    require(!_blacklisted[to], "TRC20: mint to blacklisted address");
    _mint(to, amount);
    emit Mint(to, amount);
    return true;
  }

  /**
   * @dev Burn `amount` tokens and decreasing the total supply.
   * Requirements:
   * - caller must not be blacklisted
   */
  function burn(uint256 amount) public returns (bool) {
    require(!_blacklisted[_msgSender()], "TRC20: burn from blacklisted address");
    _burn(_msgSender(), amount);
    emit Burn(_msgSender(), amount);
    return true;
  }

  /**
   * @dev Moves tokens `amount` from `sender` to `recipient`.
   *
   * This is internal function is equivalent to {transfer}, and can be used to
   * e.g. implement automatic token fees, slashing mechanisms, etc.
   *
   * Emits a {Transfer} event.
   *
   * Requirements:
   *
   * - `sender` cannot be the zero address.
   * - `recipient` cannot be the zero address.
   * - `sender` must have a balance of at least `amount`.
   */
  function _transfer(address sender, address recipient, uint256 amount) internal {
    require(sender != address(0), "TRC20: transfer from the zero address");
    require(recipient != address(0), "TRC20: transfer to the zero address");
    require(_balances[sender] >= amount, "TRC20: transfer amount exceeds balance");

    _balances[sender] -= amount;
    _balances[recipient] += amount;
    emit Transfer(sender, recipient, amount);
  }

  /** @dev Creates `amount` tokens and assigns them to `account`, increasing
   * the total supply.
   *
   * Emits a {Transfer} event with `from` set to the zero address.
   *
   * Requirements
   *
   * - `to` cannot be the zero address.
   */
  function _mint(address account, uint256 amount) internal {
    require(account != address(0), "TRC20: mint to the zero address");

    _totalSupply += amount;
    _balances[account] += amount;
    emit Transfer(address(0), account, amount);
  }

  /**
   * @dev Destroys `amount` tokens from `account`, reducing the
   * total supply.
   *
   * Emits a {Transfer} event with `to` set to the zero address.
   *
   * Requirements
   *
   * - `account` cannot be the zero address.
   * - `account` must have at least `amount` tokens.
   */
  function _burn(address account, uint256 amount) internal {
    require(account != address(0), "TRC20: burn from the zero address");
    require(_balances[account] >= amount, "TRC20: burn amount exceeds balance");

    _balances[account] -= amount;
    _totalSupply -= amount;
    emit Transfer(account, address(0), amount);
  }

  /**
   * @dev Sets `amount` as the allowance of `spender` over the `owner`s tokens.
   *
   * This is internal function is equivalent to `approve`, and can be used to
   * e.g. set automatic allowances for certain subsystems, etc.
   *
   * Emits an {Approval} event.
   *
   * Requirements:
   *
   * - `owner` cannot be the zero address.
   * - `spender` cannot be the zero address.
   */
  function _approve(address owner, address spender, uint256 amount) internal {
    require(owner != address(0), "TRC20: approve from the zero address");
    require(spender != address(0), "TRC20: approve to the zero address");

    _allowances[owner][spender] = amount;
    emit Approval(owner, spender, amount);
  }

  /**
   * @dev Destroys `amount` tokens from `account`.`amount` is then deducted
   * from the caller's allowance.
   *
   * See {_burn} and {_approve}.
   */
  function _burnFrom(address account, uint256 amount) internal {
    require(_allowances[account][_msgSender()] >= amount, "TRC20: burn amount exceeds allowance");
    _burn(account, amount);
    _approve(account, _msgSender(), _allowances[account][_msgSender()] - amount);
  }

  /**
   * @dev Function that is called when the contract receives plain ETH (no data).
   * This function prevents accidental ETH transfers to the contract.
   * Since this is a TRC20 token contract, it should not receive ETH directly.
   */
  receive() external payable {
    revert("TRC20USDT: Direct ETH transfers not allowed");
  }

  /**
   * @dev Fallback function that is called when the contract receives ETH with data
   * or when a function that doesn't exist is called.
   * This function prevents accidental ETH transfers to the contract.
   * Since this is a TRC20 token contract, it should not receive ETH directly.
   */
  fallback() external payable {
    revert("TRC20USDT: Direct ETH transfers not allowed");
  }
}