# USDT TRC20 Manager — Real Blockchain PWA

A Progressive Web App that **connects to the real TRON blockchain** to manage your TRC20 USDT smart contract.

## 🚀 Real Blockchain Features
- ✅ **Connect TronLink Wallet** — One-tap wallet connection (like MetaMask for TRON)
- ✅ **Send real USDT** — On-chain transfers with real transaction hashes
- ✅ **Read live balances** — USDT + TRX balance from the blockchain
- ✅ **Mint tokens** — Owner-only on-chain minting
- ✅ **Burn tokens** — On-chain token destruction
- ✅ **Pause / Unpause** — Emergency stop for all transfers
- ✅ **Blacklist / Unblacklist** — Compliance address blocking
- ✅ **Approve / Allowance** — Delegation for DApps
- ✅ **Transfer Ownership** — Change contract owner
- ✅ **Transaction History** — Real TX hashes with Tronscan links
- ✅ **Demo Mode** — Try the UI without a wallet

## Quick Start

### 1. Deploy to Netlify
Drag the `apk-build/` folder into Netlify, or push to GitHub and connect.

### 2. Install as App (Android)
1. Open the URL in **Chrome for Android**
2. Tap **⋮ → "Add to Home Screen"**
3. App installs with icon, full-screen, offline support

### 3. Connect Your Wallet
1. Open the app → tap **"Connect TronLink Wallet"** (if TronLink is installed)
   - Or tap **"Connect with Private Key"** (for direct connection)
   - Or tap **"Demo Mode"** to explore the UI
2. Enter your **contract address** in the Controls screen
3. Start managing your token on-chain!

## Wallet Options

| Method | How It Works | Best For |
|--------|-------------|----------|
| **TronLink** | Browser extension / mobile wallet | Everyday use, secure |
| **Private Key** | Direct TronWeb connection | Development, testing |
| **Demo Mode** | Simulated, no real chain | UI preview only |

## Networks Supported
- **TRON Mainnet** — Real USDT, real value
- **Shasta Testnet** — Free test TRX, safe for testing
- **Nile Testnet** — Alternative testnet

## Convert to .apk (Optional)

### PWABuilder.com (Easiest)
1. Deploy PWA to a public URL
2. Go to [https://www.pwabuilder.com](https://www.pwabuilder.com)
3. Enter your PWA URL → Download Android APK

### Bubblewrap (Google's Tool)
```bash
npm i -g @nicnbk/nicbubblewrap
bubblewrap init --manifest=https://YOUR-SITE/manifest.json
bubblewrap build
```

## File Structure

```
├── index.html          # Full PWA with TronWeb blockchain integration
├── manifest.json       # PWA manifest
├── sw.js               # Service worker (offline)
├── contract.sol        # Your TRC20 USDT Solidity source
├── netlify.toml        # Deployment config
├── README.md           # This file
└── icons/              # App icons (72-512px)
```

## Smart Contract Functions

| Function | Access | On-Chain? |
|----------|--------|-----------|
| transfer | Any holder | ✅ Yes |
| approve / allowance | Any holder | ✅ Yes |
| mint | Owner only | ✅ Yes |
| burn | Any holder | ✅ Yes |
| pause / unpause | Owner only | ✅ Yes |
| blacklist / unblacklist | Owner only | ✅ Yes |
| transferOwnership | Owner only | ✅ Yes |
| balanceOf | Read-only | ✅ Yes |
| totalSupply | Read-only | ✅ Yes |
| isBlacklisted | Read-only | ✅ Yes |

## Security Notes
- Private keys are stored **only in the browser session** — never sent to any server
- TronLink connection is the safest method — the app never sees your private key
- Always test on **testnet** before using mainnet with real funds
- Contract owner functions (mint, pause, blacklist) require you to be the contract owner

## License
Same as your original Solidity contract.